package net.ccbluex.liquidbounce.discord

import net.ccbluex.liquidbounce.utils.MinecraftInstance


// TODO: Restore this functionality.
class ClientRichPresence : MinecraftInstance() {
    fun setup() {
    }

    fun update() {
    }

    fun shutdown() {
    }
}
