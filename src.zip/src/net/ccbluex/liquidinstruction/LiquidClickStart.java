package net.ccbluex.liquidinstruction;

import net.minecraft.client.main.Main;

/**
 * @author yuxiangll
 * @package net.ccbluex.liquidinstruction
 * don't mind
 * @date 2023/8/18 13:35
 */
public class LiquidClickStart {
    public static void main(String[] args)
    {
        LiquidInstructionKt.main();
    }
}
